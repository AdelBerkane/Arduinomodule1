#ifndef GENERATIONCODE_H
#define GENERATIONCODE_H

#include <stdio.h>
#include <stdlib.h>


void generation();
#endif // GENERATIONCODE_H
