#include "donnee.h"

void croiss_temps(battement T[] , int n2);

void decroiss_temps (battement T[],int n2);

void croi_pouls (battement T[] , int n2);

void decroiss_pouls (battement T[] , int n2);

void temps_donnee (battement T[],int n2);

void temps_particulier (battement T[],int n2);

void nombre_de_donnees (int n2);

void pouls_max (battement T[], int n2);

void pouls_min (battement T[], int n2);
