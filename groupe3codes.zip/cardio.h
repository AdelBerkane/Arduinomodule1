#ifndef CARDIO_H_INCLUDED
#define CARDIO_H_INCLUDED

int verifcardio(int val, int seuil, int valeurPrecedente);
int calculcardio(int tempsDetection, int previous, int seuil);

#endif // CARDIO_H_INCLUDED
