#include "donnee.h"

int affichmenu ();

void affichparticulier (battement T[], int n2 );
