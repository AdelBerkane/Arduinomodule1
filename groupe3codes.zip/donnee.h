#ifndef H_MASTRUCTURE
#define H_MASTRUCTURE

typedef struct battement
{

  int tmp;

  int pouls;

}battement;

#endif

void lancement (int tab[], int *n);

void modif (int tab[],battement T[], int n ,int *n2 );

